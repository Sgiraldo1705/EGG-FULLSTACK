/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.listas;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 *
 * @author CamiloH
 */
public class Listas {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        
        //Listas
        
        ArrayList<Integer> numerosA = new ArrayList();
        int x = 20, y = 4, a = 2, b = 6, c = 9;
        
        numerosA.add(x);
        numerosA.add(y);
        numerosA.add(a);
        numerosA.add(b);
        numerosA.add(c);
        
        for (Integer integer : numerosA) {
            System.out.println("Mostrar lista: " + integer);
        }
        
        //Conjuntos
        
        HashSet<Integer> numero = new HashSet();
        int r = 20, t = 4, d = 2, e = 6, q = 9;
        numero.add(r);
        numero.add(t);
        numero.add(d);
        numero.add(e);
        numero.add(q);
        
        for (Integer conjunto : numero) {
            System.out.println("Los valores del Conjunto: " + conjunto);
        }
        
        //Mapas
        
        HashMap<String,Integer> mapa = new HashMap(); 
        int v = 20, n = 4, m = 2, l = 6, p = 9;
        String nom1 = "carlos", nom2 = "Claudia", nom3 = "Sara", nom4 = "Ramiro",
                nom5 = "Maria";
        
        mapa.put(nom1, v);
        mapa.put(nom2, n);
        mapa.put(nom3, m);
        mapa.put(nom4,l);
        mapa.put(nom5, p);
        
        for (Map.Entry<String, Integer> entry : mapa.entrySet()) {
            Object key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println("LLave: " + key);
            System.out.println("Valor: " + value);
        } 
        
    }
}
